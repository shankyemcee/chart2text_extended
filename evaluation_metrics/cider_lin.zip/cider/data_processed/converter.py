import os
import csv
import re
import json

# [{"image_id": "2008_003849.jpg", "caption": "photo of a television screen showing a movie"}, {"image_id": "2008_003849.jpg", "caption": "photo of a television screen showing a movie"}]


# T5 on statista 38.27 / 4.68 / 2.819
cand_file = '/data/lin/chart2text/transformers/ckpts/statista_title/test3827/generated_predictions.txt'
ref_file = '/data/lin/chart2text/transformers/ckpts/statista_title/test3827/output_references.txt'

# bart on statista  37.46 / 4.398 / 2.587
# cand_file = '/data/lin/chart2text/transformers/ckpts/statista_bart/test_3746/generated_predictions.txt'
# ref_file = '/data/lin/chart2text/transformers/ckpts/statista_bart/test_3746/output_references.txt'


# t5 on pew 14.15 / 1.85 / 0.54
# cand_file = '/data/lin/chart2text/transformers/ckpts/pew_t5/test_1414/generated_predictions.txt'
# ref_file = '/data/lin/chart2text/transformers/ckpts/pew_t5/test_1414/output_references.txt'

# bart on pew 13.32 / 1.808 /0.489
# cand_file = '/data/lin/chart2text/transformers/ckpts/pew_bart/test_13.32/generated_predictions.txt'
# ref_file = '/data/lin/chart2text/transformers/ckpts/pew_bart/test_13.32/output_references.txt'

with open(ref_file,'r') as f:
	refs = f.readlines()

with open(cand_file,'r') as f:
	cands = f.readlines()

res_ref = []
res_cand = []
for i, ref in enumerate(refs):
	res_ref.append({'image_id':i,'caption':ref})
	res_cand.append({'image_id':i,'caption':cands[i]})

with open('refs.json','w') as f:
	f.write(json.dumps(res_ref))
with open('cands.json','w') as f:
	f.write(json.dumps(res_cand))
